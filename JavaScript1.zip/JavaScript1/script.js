for (let i = 1; i <= 20; i++) {

    if (i != 5 && i != 10 && i != 15) {

        document.getElementById("list1").innerHTML += `<li>${i}</li>`;

    }

}
